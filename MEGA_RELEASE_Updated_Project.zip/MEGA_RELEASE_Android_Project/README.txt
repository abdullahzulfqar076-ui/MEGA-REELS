MEGA RELEASE - Android project (updated demo)

Included in this ZIP:
- Black/red MEGA RELEASE layout and local video preview
- MEGA RELEASE OFFICIAL channel screen
- Local announcement/post list (text and selected video filename)
- Admin Panel labelled MEGA RELEASE OFFICIAL
- Sample user list with Ban/Unban buttons; sample status is stored on this device

IMPORTANT LIMITATIONS:
This is still a FRONT-END / LOCAL DEMO, not a complete online social network.
The Admin Panel and Ban/Unban buttons only change sample records in this app on this device.
Official channel posts are stored locally and are NOT sent to other users.
There is no secure admin login, real user database, cloud video upload, server-side ban enforcement,
Gmail/phone OTP, notifications, or live streaming. Never put a real password in this demo.
A real multi-user app needs a backend server, database, secure authentication, and admin authorization.

To build an APK:
1. Open this project in Android Studio (computer) or a compatible Android IDE.
2. Allow Gradle sync and install Android SDK Platform 35 if prompted.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
This ZIP is a project, not an APK.
